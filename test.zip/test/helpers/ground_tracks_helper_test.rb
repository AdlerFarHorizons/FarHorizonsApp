require 'test_helper'

class GroundTracksHelperTest < ActionView::TestCase
end
