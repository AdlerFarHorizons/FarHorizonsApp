require 'test_helper'

class BeaconReceiversHelperTest < ActionView::TestCase
end
