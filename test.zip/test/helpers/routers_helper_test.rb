require 'test_helper'

class RoutersHelperTest < ActionView::TestCase
end
