require 'test_helper'

class BeaconTransmittersHelperTest < ActionView::TestCase
end
