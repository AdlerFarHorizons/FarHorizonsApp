require 'test_helper'

class LocationDevicesHelperTest < ActionView::TestCase
end
