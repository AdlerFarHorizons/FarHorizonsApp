require 'test_helper'

class BeaconsHelperTest < ActionView::TestCase
end
