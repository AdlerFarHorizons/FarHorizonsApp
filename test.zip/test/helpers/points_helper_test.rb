require 'test_helper'

class PointsHelperTest < ActionView::TestCase
end
