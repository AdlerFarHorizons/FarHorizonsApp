require 'test_helper'

class PredictedTracksHelperTest < ActionView::TestCase
end
