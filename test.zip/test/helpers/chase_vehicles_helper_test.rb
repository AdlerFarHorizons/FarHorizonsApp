require 'test_helper'

class ChaseVehiclesHelperTest < ActionView::TestCase
end
