require 'test_helper'

class PlatformsHelperTest < ActionView::TestCase
end
