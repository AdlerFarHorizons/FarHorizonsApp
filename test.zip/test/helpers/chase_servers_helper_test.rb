require 'test_helper'

class ChaseServersHelperTest < ActionView::TestCase
end
