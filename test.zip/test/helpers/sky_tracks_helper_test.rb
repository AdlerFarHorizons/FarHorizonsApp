require 'test_helper'

class SkyTracksHelperTest < ActionView::TestCase
end
