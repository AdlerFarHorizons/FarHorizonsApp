require 'test_helper'

class PlatformServersHelperTest < ActionView::TestCase
end
