require 'test_helper'

class SkyTrackTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
