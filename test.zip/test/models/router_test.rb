require 'test_helper'

class RouterTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
