require 'test_helper'

class ChaseVehicleTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
