require 'test_helper'

class BeaconTransmitterTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
