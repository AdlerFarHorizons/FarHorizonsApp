require 'test_helper'

class LocationDeviceTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
