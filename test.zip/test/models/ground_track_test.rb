require 'test_helper'

class GroundTrackTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
