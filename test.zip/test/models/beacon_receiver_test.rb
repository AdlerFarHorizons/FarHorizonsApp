require 'test_helper'

class BeaconReceiverTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
